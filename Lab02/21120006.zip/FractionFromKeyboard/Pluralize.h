#include <string>
#include <sstream>

std::string Pluralize(int n, std::string singular, std::string plural);

